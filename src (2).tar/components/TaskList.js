import React from "react";
import { deleteTask } from "../taskService";

const TaskList = ({ tasks, onEdit, onTaskDeleted }) => {
  return (
    <ul>
      {tasks.map((task) => (
        <li key={task.id}>
          {task.title}
          <button onClick={() => onEdit(task)}>Edit</button>
          <button onClick={() => deleteTask(task.id).then(onTaskDeleted)}>
            Delete
          </button>
        </li>
      ))}
    </ul>
  );
};

export default TaskList;
